'use strict';

export const A = 1;
export const B = 3;
export const C = 4;