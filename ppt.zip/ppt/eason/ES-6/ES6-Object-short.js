'use strict'
// 属性名表达式和简洁表示法不可以同时使用

// 属性以及方法简洁表示法
var birth = '2000/01/01';

var Person = {

  name: 'Eason',

  //等同于birth: birth
  birth,

  // 等同于hello: function ()...
  hello() { console.log('my name is ', this.name); }

};
console.log(Person);
console.log(Person.hello());
/*
// 属性名表达式
var lastWord = 'last word';

var a = {
  'first word': 'hello',
  [lastWord]: 'world'
};

// a['first word']
console.log(a['first word']);

// a[lastWord]
console.log(a[lastWord]);

// a['last word']
console.log(a['last word']);
*/
