'use strict'

// Array.from方法用于将两类对象转为真正的数组：类似数组的对象（array-like object）和可遍历（iterable）的对象（包括ES6新增的数据结构Set和Map


let arrayLike = {
    '0': '1',
    '1': '2',
    '2': '3',
    length: 3
};
// ES5的写法
var arr1 = [].slice.call(arrayLike); // ['1', '2', '3']
console.log("arr1 : ");
console.log(arr1);
// ES6的写法
let arr2 = Array.from(arrayLike); // ['1', '2', '3']
console.log("arr2");
console.log(arr2);
