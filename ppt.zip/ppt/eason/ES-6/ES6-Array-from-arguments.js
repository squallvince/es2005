'use strict'

let aLike = {
    '0': '1',
    '1': '2',
    '2': '3',
    length: 3
};

// Array.from 可以接受第二个参数，作用类似于数组的map方法

console.log(Array.from(aLike, x => x * x));

// 等同于
console.log(Array.from(aLike).map(x => x * x));

//Arrow function
console.log(Array.from([1, 2, 3], (x) => x * x));
