'use strict'

//__proto__属性（前后各两个下划线），用来读取或设置当前对象的prototype对象

//Object.setPrototypeOf 用来设置一个对象的prototype对象

//Object.getPrototypeOf 用于读取一个对象的prototype对象
