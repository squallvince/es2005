'use strict'

//ES6 遍历对象熟悉

//for...in循环遍历对象自身的和继承的可枚举属性（不含Symbol属性）

//Object.keys返回一个数组，包括对象自身的（不含继承的）所有可枚举属性（不含Symbol属性）

//Object.getOwnPropertyNames返回一个数组，包含对象自身的所有属性（不含Symbol属性，但是包括不可枚举属性）

//Object.getOwnPropertySymbols返回一个数组，包含对象自身的所有Symbol属性

//Reflect.ownKeys返回一个数组，包含对象自身的所有属性，不管是属性名是Symbol或字符串，也不管是否可枚举

//Reflect.enumerate返回一个Iterator对象，遍历对象自身的和继承的所有可枚举属性（不含Symbol属性），与for...in循环相同
