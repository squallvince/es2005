'use strict'

//Array.of方法用于将一组值，转换为数组
Array.of(3, 11, 8)
// console.log(Array.of(3, 11, 8))

Array.of(3)
// console.log(Array.of(3))

Array.of(3).length
// console.log(Array.of(3).length);

Array.of()
// console.log(Array.of());
