'use strict'

//扩展运算符（...）也可以将某些数据结构转为数组

// NodeList对象
let arrayDiv  = [...document.querySelectorAll('div')];

console.log(arrayDiv.length);
