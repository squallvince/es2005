'use strict'

var obj = { a: 1, b: 2, c: 3 };

for (var key of Object.keys(obj)) {
  // ['a', 'b', 'c']
}

for (var value of Object.values(obj)) {
  // [1, 2, 3]
}

for (var entry of Object.entries(obj)) {
  // ['a', 1], ['b', 2], ['c', 3]
}

// for (var [key, value] of entries(obj)) {
//   // ['a', 1], ['b', 2], ['c', 3]
// }
