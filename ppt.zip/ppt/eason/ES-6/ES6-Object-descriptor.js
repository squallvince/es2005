'use strict'

//获取属性的描述对象
 var obj = { foo: 123 };
 Object.getOwnPropertyDescriptor(obj, 'foo')
 //   { value: 123,
 //     writable: true,
 //     enumerable: true,
 //     configurable: true }
 console.log(Object.getOwnPropertyDescriptor(obj, 'foo'));
