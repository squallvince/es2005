'use strict'

//用来将源对象的所有可枚举属性，复制到目标对象, 同名属性覆盖
var target = { a: 1, b: 1 };

var source1 = { b: 2, c: 2 };
var source2 = { c: 3 };

Object.assign(target, source1, source2);
console.log(target) // {a : 1, b: 2, c: 3}

//无法深度拷贝（替换）
var target = { a: { b: 'c', d: 'e' } }
var source = { a: { b: 'hello' } }
Object.assign(target, source)
console.log(Object.assign(target, source));
// { a: { b: 'hello' } }

//数组操作 ！！！把数组视为对象 ！！！
Object.assign([1, 2, 3], [4, 5])
console.log(Object.assign([1, 2, 3], [4, 5]));
