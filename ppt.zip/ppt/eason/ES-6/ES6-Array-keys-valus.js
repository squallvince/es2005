'use strict'
//keys()是对键名的遍历
//values()是对键值的遍历
//entries()是对键值对的遍历

for (let index of ['a', 'b'].keys()) {
  console.log(index);
}

for (let elem of ['a', 'b'].values()) {
  console.log(elem);
}

for (let value of ['a', 'b'].entries()) {
  console.log(value);
}

//解构babel暂时不支持
// for (let [index, elem] of ['a', 'b'].entries()) {
//   console.log(index, elem);
// }

//手动调用遍历器对象的next方法
// let letter = ['a', 'b', 'c'];
// let entries = letter.entries();
// console.log(entries.next().value); // [0, 'a']
// console.log(entries.next().value); // [1, 'b']
// console.log(entries.next().value); // [2, 'c']
