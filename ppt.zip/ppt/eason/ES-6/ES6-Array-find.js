'use strict'
// Array.find : 用于找出第一个符合条件的数组成员/位置，弥补了数组的IndexOf方法不足
// find  接受参数 value, index，  array
[1, 3, 5, 7, 9].find(n=> n>5)
// console.log("[1, 3, 5, 7, 9] find item bigger than 5 : " + [1, 3, 5, 7, 9].find(n=> n>5));
[1, 3, 5, 7, 9].findIndex(n=> n>5)
// console.log("[1, 3, 5, 7, 9] findIndex of item bigger than 5 :" + [1, 3, 5, 7, 9].findIndex(n=> n>5));

[NaN].indexOf(NaN)
// console.log("[NaN] indexOf NaN : " + [NaN].indexOf(NaN));

[NaN].findIndex(y => Object.is(NaN, y))
// console.log("[NaN] findIndex NaN : " + [NaN].findIndex(y => Object.is(NaN, y)));

//ES7
[NaN].includes(NaN)
// console.log([NaN].includes(NaN));

[1, 2, 3].includes(3, -1)
// console.log([1, 2, 3].includes(3, -1));
