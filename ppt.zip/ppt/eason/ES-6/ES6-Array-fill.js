'use strict'

//fill方法使用给定值，填充一个数组
['a', 'b', 'c'].fill(7);
// console.log(['a', 'b', 'c'].fill(7));

//接受第二个和第三个参数，用于指定填充的起始位置和结束位置
['a', 'b', 'c'].fill(7, 1, 2)
// console.log(['a', 'b', 'c'].fill(7, 1, 2));
