'use strict'

// Array.copyWithin 在当前数组内部，将指定位置的成员复制到其他位置（会覆盖原有成员），然后返回当前数组
//Array.prototype.copyWithin(target, start = 0, end = this.length)
[1, 2, 3, 4, 5].copyWithin(0, 3, 4);
//console.log([1, 2, 3, 4, 5].copyWithin(0, 3, 4));
