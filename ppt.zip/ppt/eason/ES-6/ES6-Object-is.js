'use strict'

//用来比较两个值是否严格相等，与严格比较运算符（===）的行为基本一致
//special
//ES5
+0 === -0
// console.log(+0 === -0);
NaN === NaN
// console.log(NaN === NaN);

//ES6
Object.is(+0, -0)
// console.log(Object.is(+0, -0));
Object.is(NaN, NaN)
// console.log(Object.is(NaN, NaN));
