'use strict'

var person = {
  sayName() {
    console.log(this.name);
  },
  get firstName() {
    return "Nicholas"
  }
}

person.sayName.name   // "sayName"

//取值函数，则会在方法名前加上get
//存值函数，方法名的前面会加上set
person.firstName.name // "get firstName"


//特殊情况
//bind方法创造的函数，name属性返回“bound”加上原函数的名字
var doSomething = function() {
  // ...
};
doSomething.bind().name // "bound doSomething"

//Function构造函数创造的函数，name属性返回“anonymous”
(new Function()).name // "anonymous"
